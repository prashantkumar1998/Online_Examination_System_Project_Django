from django.apps import AppConfig


class OnlineexaminationConfig(AppConfig):
    name = 'OnlineExamination'
